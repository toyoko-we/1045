'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'facebook-messenger';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f39f';
var svgPathData = 'M224.5 32C98 32 0 124.44 0 249.29 0 314.6 26.83 371 70.51 410c7.55 6.78 6 10.71 7.27 52.6A18 18 0 0 0 103 478.47c47.8-21 48.41-22.71 56.51-20.5C297.93 496.08 448 407.47 448 249.29 448 124.44 351 32 224.5 32zm134.79 167.21l-66 104.39a33.75 33.75 0 0 1-48.69 9l-52.4-39.29a13.49 13.49 0 0 0-16.21.05L105.16 327c-9.44 7.17-21.82-4.15-15.45-14.15l66-104.39a33.76 33.76 0 0 1 48.69-9l52.45 39.26a13.51 13.51 0 0 0 16.22 0l70.82-53.64c9.39-7.19 21.77 4.13 15.4 14.13z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faFacebookMessenger = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
import config from './rollup.config';

config.format = 'es';
config.dest = 'dist/localforage-removeitems.es6.js';

export default config;

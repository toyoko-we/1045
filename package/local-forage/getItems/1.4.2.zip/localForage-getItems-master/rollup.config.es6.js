import config from './rollup.config';

config.format = 'es';
config.dest = 'dist/localforage-getitems.es6.js';

export default config;

var gulp = require('gulp');
var concat = require('gulp-concat');

gulp.task('default', function() {
  return gulp.src(
    ['js/load-image.js',
     'js/load-image-scale.js',
     'js/load-image-meta.js',
     'js/load-image-fetch.js',
     'js/load-image-orientation.js',
     'js/load-image-exif.js',
     'js/load-image-exif-map.js',
     'js/load-image-iptc.js',
     'js/load-image-iptc-map.js',
     ])
    .pipe(concat('load-image.all.js'))
    .pipe(gulp.dest('js/'));
});
require('../modules/web.timers');
module.exports = require('../modules/_core').setTimeout;

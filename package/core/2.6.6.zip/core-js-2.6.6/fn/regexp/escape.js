require('../../modules/core.regexp.escape');
module.exports = require('../../modules/_core').RegExp.escape;

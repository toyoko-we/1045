require('../../modules/es6.reflect.apply');
module.exports = require('../../modules/_core').Reflect.apply;

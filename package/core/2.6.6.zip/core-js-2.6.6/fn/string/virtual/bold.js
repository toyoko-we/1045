require('../../../modules/es6.string.bold');
module.exports = require('../../../modules/_entry-virtual')('String').bold;

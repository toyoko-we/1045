module.exports=require('theory')
('interface',function(a){
	return ":)";
},['../deps/discrete','../deps/key/key']);
root.opts.key = {host:'/deps'};
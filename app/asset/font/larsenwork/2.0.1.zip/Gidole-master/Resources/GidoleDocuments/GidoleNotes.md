**Possible weights**
```
One         100
Two         200		5.5%
Three       300		13%
Four        400		22.5%
Five        500		34%

ExtraLight  100		47.5%
Light       200		63%
Book        300		80.5%
Regular     400		156/140 150/134(124) pt
Medium      500		20%
SemiBold    600		40%
Bold        700		60%
Ekstrabold  800		80%
BLack       900
```

**After build**
dcaron, lcaron, tcaron rb 30
napostrophe tix + lb 50

**Sizes**
```
```

**Regular**
```
  () 140/100

```

**Misc**
```
Ink trap (e.g. b)
  Interpolatecpsonmotion ON
  n: 30pt right, 6pt right
Terminals
  C: 108%   114t118b
  c,2: 112%   124t128b
  3,t,j: 116% 128
  5,3,J: 120%
  e: 124%     136
  f: 128%     144
  S: 132%     140
  g: 132%     146
  s: 136%     144
  a: 148%     132
Copy+reg:
  62%
  112/100
sup general
  x=60%, y=50%
  132/118
  12pt overshoot

a sup
  660 tall
  bottom dot 15pt left
2 sup
  648 tall
x sup
  754 tall

```

Packaging [Moment](momentjs.org) for [Meteor.js](http://meteor.com).

# Issues

If you encounter an issue while using this package, please CC @dandv when you file it in this repo.

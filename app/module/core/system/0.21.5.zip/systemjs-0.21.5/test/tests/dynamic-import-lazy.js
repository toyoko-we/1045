System.register([], function (_export) {
  return {
    execute: function () {
      _export('lazyValue', 5);
    }
  };
});

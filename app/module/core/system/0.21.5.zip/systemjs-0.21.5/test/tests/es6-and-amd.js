export {default as amd_module} from './eaa-amd.js';
export {default as es6_module} from './eaa-es6.js';
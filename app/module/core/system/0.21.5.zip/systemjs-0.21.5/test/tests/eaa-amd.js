define([], function() {
  return 'AMD Module';
});
exports.locate = function (load) {
  return load.address + '.js';
};

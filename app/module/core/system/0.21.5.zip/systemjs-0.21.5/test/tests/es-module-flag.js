exports.exportName = 'export';
exports['default'] = 'default export';
exports.__esModule = true;
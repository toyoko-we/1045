foo = "barz";
baz = "chaz";
this.zed = "ted";
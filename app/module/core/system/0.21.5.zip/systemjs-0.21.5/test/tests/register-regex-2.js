/**
 * @file file comment
 * ...
 */

/**
 * module comment
 * ...
 */
System.register([], function() {
  return {
    setters: [],
    execute: function() {}
  };
}); 
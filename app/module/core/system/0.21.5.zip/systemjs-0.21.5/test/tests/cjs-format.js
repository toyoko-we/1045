"format cjs";
if (typeof define != 'undefined')
  define(function() {});
exports.cjs = 'cjs';

import cjsFunc from './es-named-import-cjs-cjs.js';
export var cjsFuncValue = cjsFunc.cjsFunc();

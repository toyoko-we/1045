exports.dirname = __dirname;
exports.filename = __filename;
exports.global = global;
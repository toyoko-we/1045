define(function(require) {
  require(["tests/amd-dep.js"]);
});

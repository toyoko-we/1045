System.register([], function(exports_1) {
    function f1() { return 1; }
    exports_1("f1", f1);
    function f2() { return 2; }
    exports_1("f2", f2);
    function f3() { return 3; }
    exports_1("f3", f3);
    return {
        setters:[],
        execute: function() {
        }
    }
});

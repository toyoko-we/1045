module.exports = require('./test.css!');

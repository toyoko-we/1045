(function (g) {
  g.peerExecuted = true;
})(typeof self !== 'undefined' ? self : global);

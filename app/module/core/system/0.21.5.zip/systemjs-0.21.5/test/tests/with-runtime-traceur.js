System.register([], function($__export) {
  "use strict";
  var __moduleName = "test";
  var c;
  return {
    setters: [],
    execute: function() {
      c = $__export("c", (function() {
        var c = function c() {};
        return ($traceurRuntime.createClass)(c, {}, {});
      }()));
    }
  };
});

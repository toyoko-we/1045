import * as mod from './es6-loading-amd-dep.js';

export var g = mod.default;
require('../../modules/es6.number.is-integer');
module.exports = require('../../modules/_core').Number.isInteger;

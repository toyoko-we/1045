require('../../modules/es6.number.parse-int');
module.exports = require('../../modules/_core').Number.parseInt;

require('../../modules/es7.reflect.get-own-metadata');
module.exports = require('../../modules/_core').Reflect.getOwnMetadata;

require('../../../modules/es6.string.code-point-at');
module.exports = require('../../../modules/_entry-virtual')('String').codePointAt;

require('../../modules/es6.typed.float32-array');
module.exports = require('../../modules/_core').Float32Array;

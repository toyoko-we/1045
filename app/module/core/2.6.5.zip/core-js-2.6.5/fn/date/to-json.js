require('../../modules/es6.date.to-json');
module.exports = require('../../modules/_core').Date.toJSON;

import config from './rollup.config';

config.format = 'es';
config.dest = 'dist/localforage-setitems.es6.js';

export default config;

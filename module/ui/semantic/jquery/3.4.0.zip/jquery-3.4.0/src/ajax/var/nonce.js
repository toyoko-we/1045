define( function() {
	"use strict";

	return Date.now();
} );
